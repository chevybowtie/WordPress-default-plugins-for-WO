<div class="postbox">
<div class="inside">
	<p><b>My Wordpress Login Logo</b> lets you to add a custom logo in your wordpress login page instead of the usual wordpress logo.</p><p> It also allows you to specify the height and width of the logo. By adding your custom logo in your login page, you can make your website more proffesional and also impress the guest bloggers and other users who view these pages.</p>
	<p>I hope you enjoyed the plugin. Don't forget to rate us!</p>
	<h4>Follow Me :)</h4>
		<a href="https://twitter.com/afsalrahim" class="twitter-follow-button" data-show-count="false" data-show-screen-name="false">Follow @afsalrahim</a>
		<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
		</p>
		<p>For more help <a href="mailto:4fsalrahim@gmail.com">email me</a>.</p>
</div>
</div>				