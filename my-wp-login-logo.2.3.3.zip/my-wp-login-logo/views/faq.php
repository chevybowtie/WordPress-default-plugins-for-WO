<div class="postbox">
	<button class="handlediv button-link" aria-expanded="true" type="button">
		<span class="screen-reader-text">Toggle panel: Help & FAQ</span>
		<span class="toggle-indicator" aria-hidden="true"></span>
	</button>
	<h2 class="hndle ui-sortable-handle">
		<span>Help & FAQ</span>
	</h2>

	<div class="inside">
			<p><h4>Q1. How does it works?</h4>
			[-] Upload your desired logo clicking the Upload Image button.<br/>
			[-] Provide your custom height and width for the logo and press Save<br/>
			[-] That's it! You can now logout and check your awesome new login page.
			</p>
			<p><h4>Q2. How to change the logo size?</h4>
			Simply input your desired logo height and width in the given fields to change the displayed logo size.</p>
			<p><h4>Q3. What is the recommened logo size?</h4>
			Less than or equal to 320px width and 70px height is the recommended logo size for your Wordpress Login Page.</p>
	</div>
</div>
